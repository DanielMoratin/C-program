﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLS___AppDev22
{
    class DataBaseBLS
    {
        private int cntPlayer = 0, cntTeam = 0;
        public Team[] team = new Team[1];
        public Player[] player = new Player[1];
        public DataBaseBLS()
        {

        }

        public void addPlayer(string pid, string pf, string pl, string pa, string mp, string sp)
        {
            if (cntPlayer >= player.Length)
            {
                player[cntPlayer++] = new Player(pid, pf, pl, pa, mp, sp);
            }
            else
            {
                Player[] temp = new Player[cntPlayer + 1];
                for (int i = 0; i < cntPlayer; i++)
                    temp[i] = player[i];
                temp[cntPlayer++] = new Player(pid, pf, pl, pa, mp, sp);
                player = new Player[temp.Length];
                for (int i = 0; i < player.Length; i++)
                    player[i] = temp[i];
            }
        }

        public void addTeam(string tid, string tn, string to, string tp)
        {
            if (cntTeam >= team.Length)
            {
                team[cntTeam++] = new Team(tid, tn, to, tp);
            }
            else
            {
                Team[] temp = new Team[cntTeam + 1];
                for (int i = 0; i < cntTeam; i++)
                    temp[i] = team[i];
                temp[cntTeam++] = new Team(tid, tn, to, tp);
                team = new Team[temp.Length];
                for (int i = 0; i < team.Length; i++)
                    team[i] = temp[i];
            }
        }

        public Team findTeam(string tid)
        {
            for (int i = 0; i < cntTeam; i++)
            {
                if (team[i].teamId == tid)
                {
                    return team[i];
                }
            }
            return null;
        }

        public Player findPlayer(string pid)
        {
            for (int i = 0; i < player.Length; i++)
            {
                if (player[i].playerId == pid)
                {
                    return player[i];
                }
            }
            return null;
        }
    }
}
