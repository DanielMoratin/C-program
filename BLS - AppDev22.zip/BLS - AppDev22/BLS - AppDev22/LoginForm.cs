﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLS___AppDev22
{
    public partial class LoginForm : Form
    {
        int mov, movX, movY;
        public int mode = 0;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            //this.Location = Screen.AllScreens[0].WorkingArea.Location;
            adminLogin.getLoginForm(this);
        }

        private void LoginForm_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void LoginForm_MouseMove(object sender, MouseEventArgs e)
        {
            if(mov == 1){
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void LoginForm_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void RightPanel_MouseDown(object sender, MouseEventArgs e)
        {
            LoginForm_MouseDown(sender, e);
        }

        private void RightPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1) this.SetDesktopLocation(MousePosition.X - movX - 300, MousePosition.Y - movY);
        }

        private void RightPanel_MouseUp(object sender, MouseEventArgs e)
        {
            LoginForm_MouseUp(sender, e);
        }

        private void adminLogin1_MouseDown(object sender, MouseEventArgs e)
        {
            LoginForm_MouseDown(sender, e);
        }

        private void adminLogin1_MouseMove(object sender, MouseEventArgs e)
        {
            LoginForm_MouseMove(sender, e);
        }

        private void adminLogin1_MouseUp(object sender, MouseEventArgs e)
        {
            LoginForm_MouseUp(sender, e);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void btnAdmin_Click(object sender, EventArgs e)
        {
            adminLogin.Visible = true;
        }
        public void Restart()
        {
            adminLogin.Visible = false;
        }

        private void btnGuest_Click(object sender, EventArgs e)
        {
            GuestForm gf = new GuestForm(this);
            gf.Show();
            this.Visible = false;
        }

    }
}
