﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLS___AppDev22
{
    public partial class SettingForm : Form
    {
        int mov, movX, movY;
        LoginForm lf;
        GuestForm gf;
        public SettingForm(LoginForm lf, GuestForm gf)
        {
            InitializeComponent();
            this.lf = lf;
            this.gf = gf;
            if (lf.mode == 1)
            {
                Header.BackColor = Color.FromArgb(255, 64, 64, 64);
                panel1.BackColor = Color.FromArgb(255, 64, 64, 64);
                panel2.BackColor = Color.FromArgb(255, 64, 64, 64);
                panel3.BackColor = Color.FromArgb(255, 64, 64, 64);
            }
        }

        private void SettingForm_Load(object sender, EventArgs e)
        {
            this.CenterToParent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Header_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void Header_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
            {
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void Header_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void BtnApply_Click(object sender, EventArgs e)
        {
            if (rbtnDark.Checked)
            {
                DarkAni.Start();
            }else if (rbtnLight.Checked)
            {
                LightAni.Start();                
            }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            lf.Visible = true;
            lf.Restart();
            gf.Close();
            this.Close();
        }

        private void DarkAni_Tick(object sender, EventArgs e)
        {
            if (Header.BackColor == Color.MediumBlue)
            {
                Header.BackColor = Color.FromArgb(255, 0, 0, 192);
                panel1.BackColor = Color.FromArgb(255, 0, 0, 192);
                panel2.BackColor = Color.FromArgb(255, 0, 0, 192);
                panel3.BackColor = Color.FromArgb(255, 0, 0, 192);
            }
            else if (Header.BackColor == Color.FromArgb(255, 0, 0, 192))
            {
                Header.BackColor = Color.DarkBlue;
                panel1.BackColor = Color.DarkBlue;
                panel2.BackColor = Color.DarkBlue;
                panel3.BackColor = Color.DarkBlue;
            }
            else if (Header.BackColor == Color.DarkBlue)
            {
                Header.BackColor = Color.Navy;
                panel1.BackColor = Color.Navy;
                panel2.BackColor = Color.Navy;
                panel3.BackColor = Color.Navy;
            }
            else if (Header.BackColor == Color.Navy)
            {
                Header.BackColor = Color.FromArgb(255, 0, 0, 64);
                panel1.BackColor = Color.FromArgb(255, 0, 0, 64);
                panel2.BackColor = Color.FromArgb(255, 0, 0, 64);
                panel3.BackColor = Color.FromArgb(255, 0, 0, 64);
            }
            else if (Header.BackColor == Color.FromArgb(255,0,0,64))
            {
                Header.BackColor = Color.FromArgb(255, 64, 64, 64);
                panel1.BackColor = Color.FromArgb(255, 64, 64, 64);
                panel2.BackColor = Color.FromArgb(255, 64, 64, 64);
                panel3.BackColor = Color.FromArgb(255, 64, 64, 64);
                DarkAni.Stop();
            }
            lf.mode = 1;
        }

        private void LightAni_Tick(object sender, EventArgs e)
        {
            if (Header.BackColor == Color.FromArgb(255, 64, 64, 64))
            {
                Header.BackColor = Color.FromArgb(255, 0, 0, 64);
                panel1.BackColor = Color.FromArgb(255, 0, 0, 64);
                panel2.BackColor = Color.FromArgb(255, 0, 0, 64);
                panel3.BackColor = Color.FromArgb(255, 0, 0, 64);
            }
            else if (Header.BackColor == Color.FromArgb(255, 0, 0, 64))
            {
                Header.BackColor = Color.Navy;
                panel1.BackColor = Color.Navy;
                panel2.BackColor = Color.Navy;
                panel3.BackColor = Color.Navy;
            }
            else if (Header.BackColor == Color.Navy)
            {
                Header.BackColor = Color.DarkBlue;
                panel1.BackColor = Color.DarkBlue;
                panel2.BackColor = Color.DarkBlue;
                panel3.BackColor = Color.DarkBlue;
            }
            else if (Header.BackColor == Color.DarkBlue)
            {
                Header.BackColor = Color.FromArgb(255, 0, 0, 192);
                panel1.BackColor = Color.FromArgb(255, 0, 0, 192);
                panel2.BackColor = Color.FromArgb(255, 0, 0, 192);
                panel3.BackColor = Color.FromArgb(255, 0, 0, 192);
            }
            else if (Header.BackColor == Color.FromArgb(255, 0, 0, 192))
            {
                Header.BackColor = Color.MediumBlue;
                panel1.BackColor = Color.MediumBlue;
                panel2.BackColor = Color.MediumBlue;
                panel3.BackColor = Color.MediumBlue;
                LightAni.Stop();
            }
            lf.mode = 0;
        }

        private void BtnLoginAsAdmin_Click(object sender, EventArgs e)
        {
            lf.Visible = true;
            lf.btnAdmin_Click(sender, e);
            gf.Close();
            this.Close();
        }

        private void BtnCloseAll_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
