﻿namespace BLS___AppDev22
{
    partial class AdminLogin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbAdminName = new System.Windows.Forms.TextBox();
            this.tbAdminPassword = new System.Windows.Forms.TextBox();
            this.btnLoginAdmin = new System.Windows.Forms.Button();
            this.blsLabel = new System.Windows.Forms.Label();
            this.label2019 = new System.Windows.Forms.Label();
            this.btnLoginGuest = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbAdminName
            // 
            this.tbAdminName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAdminName.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbAdminName.Location = new System.Drawing.Point(57, 140);
            this.tbAdminName.Name = "tbAdminName";
            this.tbAdminName.Size = new System.Drawing.Size(166, 27);
            this.tbAdminName.TabIndex = 0;
            this.tbAdminName.Text = "Admin name";
            // 
            // tbAdminPassword
            // 
            this.tbAdminPassword.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAdminPassword.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbAdminPassword.Location = new System.Drawing.Point(57, 193);
            this.tbAdminPassword.Name = "tbAdminPassword";
            this.tbAdminPassword.Size = new System.Drawing.Size(166, 27);
            this.tbAdminPassword.TabIndex = 1;
            this.tbAdminPassword.Text = "Password";
            // 
            // btnLoginAdmin
            // 
            this.btnLoginAdmin.BackColor = System.Drawing.Color.Navy;
            this.btnLoginAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoginAdmin.FlatAppearance.BorderSize = 0;
            this.btnLoginAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoginAdmin.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoginAdmin.ForeColor = System.Drawing.Color.White;
            this.btnLoginAdmin.Location = new System.Drawing.Point(57, 245);
            this.btnLoginAdmin.Name = "btnLoginAdmin";
            this.btnLoginAdmin.Size = new System.Drawing.Size(166, 29);
            this.btnLoginAdmin.TabIndex = 2;
            this.btnLoginAdmin.Text = "Login as Admin";
            this.btnLoginAdmin.UseVisualStyleBackColor = false;
            this.btnLoginAdmin.Click += new System.EventHandler(this.btnLoginAdmin_Click);
            // 
            // blsLabel
            // 
            this.blsLabel.AutoSize = true;
            this.blsLabel.BackColor = System.Drawing.Color.Transparent;
            this.blsLabel.Font = new System.Drawing.Font("Century Gothic", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blsLabel.Location = new System.Drawing.Point(0, 0);
            this.blsLabel.Name = "blsLabel";
            this.blsLabel.Size = new System.Drawing.Size(131, 77);
            this.blsLabel.TabIndex = 3;
            this.blsLabel.Text = "BLS";
            // 
            // label2019
            // 
            this.label2019.AutoSize = true;
            this.label2019.BackColor = System.Drawing.Color.Transparent;
            this.label2019.Location = new System.Drawing.Point(108, 52);
            this.label2019.Name = "label2019";
            this.label2019.Size = new System.Drawing.Size(32, 16);
            this.label2019.TabIndex = 4;
            this.label2019.Text = "2019";
            // 
            // btnLoginGuest
            // 
            this.btnLoginGuest.BackColor = System.Drawing.Color.Transparent;
            this.btnLoginGuest.FlatAppearance.BorderSize = 0;
            this.btnLoginGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoginGuest.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoginGuest.Location = new System.Drawing.Point(3, 374);
            this.btnLoginGuest.Name = "btnLoginGuest";
            this.btnLoginGuest.Size = new System.Drawing.Size(104, 23);
            this.btnLoginGuest.TabIndex = 5;
            this.btnLoginGuest.Text = "Login as Guest";
            this.btnLoginGuest.UseVisualStyleBackColor = false;
            this.btnLoginGuest.Click += new System.EventHandler(this.btnLoginGuest_Click);
            // 
            // AdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnLoginGuest);
            this.Controls.Add(this.label2019);
            this.Controls.Add(this.blsLabel);
            this.Controls.Add(this.btnLoginAdmin);
            this.Controls.Add(this.tbAdminPassword);
            this.Controls.Add(this.tbAdminName);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "AdminLogin";
            this.Size = new System.Drawing.Size(300, 400);
            this.Load += new System.EventHandler(this.AdminLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbAdminName;
        private System.Windows.Forms.TextBox tbAdminPassword;
        private System.Windows.Forms.Button btnLoginAdmin;
        private System.Windows.Forms.Label blsLabel;
        private System.Windows.Forms.Label label2019;
        private System.Windows.Forms.Button btnLoginGuest;
    }
}
