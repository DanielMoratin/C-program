﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLS___AppDev22
{
    public partial class AdminLogin : UserControl
    {
        LoginForm lf;
        public AdminLogin()
        {
            InitializeComponent();
        }

        public void getLoginForm(LoginForm lf)
        {
            this.lf = lf;
        }

        public void btnLoginAdmin_Click(object sender, EventArgs e)
        {
           
        }

        private void AdminLogin_Load(object sender, EventArgs e)
        {
            
        }

        private void btnLoginGuest_Click(object sender, EventArgs e)
        {
            GuestForm gf = new GuestForm(lf);
            gf.Show();
            lf.Visible = false;
        }
    }
}
