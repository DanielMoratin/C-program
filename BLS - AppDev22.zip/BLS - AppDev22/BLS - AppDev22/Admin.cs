﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLS___AppDev22
{
    class Admin
    {
        public string adminName, adminPass;
        public Admin()
        {
            adminName = "admin";
            adminPass = "admin";
        }
    }
}
