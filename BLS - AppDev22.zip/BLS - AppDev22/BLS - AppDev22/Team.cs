﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLS___AppDev22
{
    class Team
    {
        public string teamId = "", teamName = "", teamOwner = "", teamPlace = "";
        public int teamWins = 0, teamLoses = 0;
        public Team(string tid, string tn, string to, string tp)
        {
            teamId = tid;
            teamName = tn;
            teamOwner = to;
            teamPlace = tp;
        }
    }
}
