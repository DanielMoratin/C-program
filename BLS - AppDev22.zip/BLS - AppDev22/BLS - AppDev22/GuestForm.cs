﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLS___AppDev22
{
    public partial class GuestForm : Form
    {
        int mov, movX, movY, clickedBtn = 0;
        LoginForm logfo;
        public GuestForm(LoginForm lf)
        {
            InitializeComponent();
            logfo = lf;
        }

        private void GuestForm_Load(object sender, EventArgs e)
        {

        }

        private void GuestForm_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void GuestForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
            {
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void GuestForm_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void menuPanel_MouseDown(object sender, MouseEventArgs e)
        {
            GuestForm_MouseDown(sender, e);
        }

        private void menuPanel_MouseMove(object sender, MouseEventArgs e)
        {
            GuestForm_MouseMove(sender, e);
        }

        private void menuPanel_MouseUp(object sender, MouseEventArgs e)
        {
            GuestForm_MouseUp(sender, e);
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            clickedBtn = 0;
        }

        private void btnGames_Click(object sender, EventArgs e)
        {
            clickedBtn = 1;
        }

        private void btnStandings_Click(object sender, EventArgs e)
        {
            clickedBtn = 2;
        }

        private void btnPlayers_Click(object sender, EventArgs e)
        {
            clickedBtn = 3;
        }

        private void btnTeams_Click(object sender, EventArgs e)
        {
            clickedBtn = 4;
        }

        private void BtnSetting_Click(object sender, EventArgs e)
        {
            SettingForm sf = new SettingForm(logfo, this);
            sf.ShowDialog();
        }

        /// <summary>
        ///                                    ANIMATION CONTROLS BELOW !!!     
        /// </summary>
        public void highLightPanelLocator()
        {
            Point p = new Point();
            if (clickedBtn == 0)
            {
                p = new Point(0, 84);
            }
            else if (clickedBtn == 1)
            {
                p = new Point(0, 129);
            }
            else if (clickedBtn == 2)
            {
                p = new Point(0, 174);
            }
            else if (clickedBtn == 3)
            {
                p = new Point(0, 219);
            }
            else if (clickedBtn == 4)
            {
                p = new Point(0, 264);
            }
            highlightPanel.Location = p;
        }

        private void btnGames_MouseEnter(object sender, EventArgs e)
        {
            Point p = new Point(0, 129);
            highlightPanel.Location = p;
            btnGames.BackColor = Color.FromArgb(0, 0, 0, 30);
        }

        private void btnGames_MouseLeave(object sender, EventArgs e)
        {
            highLightPanelLocator();
            btnGames.BackColor = Color.Transparent;
        }

        private void btnMainMenu_MouseEnter(object sender, EventArgs e)
        {
            Point p = new Point(0, 84);
            highlightPanel.Location = p;
            btnMainMenu.BackColor = Color.FromArgb(0, 0, 0, 30);
        }

        private void btnMainMenu_MouseLeave(object sender, EventArgs e)
        {
            highLightPanelLocator();
            btnMainMenu.BackColor = Color.Transparent;
        }

        private void btnStandings_MouseEnter(object sender, EventArgs e)
        {
            Point p = new Point(0, 174);
            highlightPanel.Location = p;
            btnStandings.BackColor = Color.FromArgb(0, 0, 0, 30);
        }

        private void btnStandings_MouseLeave(object sender, EventArgs e)
        {
            highLightPanelLocator();
            btnStandings.BackColor = Color.Transparent;
        }

        private void btnPlayers_MouseEnter(object sender, EventArgs e)
        {
            Point p = new Point(0, 219);
            highlightPanel.Location = p;
            btnPlayers.BackColor = Color.FromArgb(0, 0, 0, 30);
        }

        private void btnPlayers_MouseLeave(object sender, EventArgs e)
        {
            highLightPanelLocator();
            btnPlayers.BackColor = Color.Transparent;
        }

        private void btnTeams_MouseEnter(object sender, EventArgs e)
        {
            Point p = new Point(0, 264);
            highlightPanel.Location = p;
            btnTeams.BackColor = Color.FromArgb(0, 0, 0, 30);
        }

        private void btnTeams_MouseLeave(object sender, EventArgs e)
        {
            highLightPanelLocator();
            btnTeams.BackColor = Color.Transparent;
        }

    }
}
