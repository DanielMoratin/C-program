﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLS___AppDev22
{
    class Player
    {
        public string playerId = "", playerFirstName = "", playerLastName = "", playerAddess = "", mainPos = "", secPos = "", playerTeam = "";
        public Player(string pid, string pf, string pl, string pa, string mp, string sp)
        {
            playerId = pid;
            playerFirstName = pf;
            playerLastName = pl;
            playerAddess = pa;
            mainPos = mp;
            secPos = sp;
        }
    }
}
