﻿namespace BLS___AppDev22
{
    partial class GuestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuPanel = new System.Windows.Forms.Panel();
            this.BtnSetting = new System.Windows.Forms.Button();
            this.btnTeams = new System.Windows.Forms.Button();
            this.btnStandings = new System.Windows.Forms.Button();
            this.btnPlayers = new System.Windows.Forms.Button();
            this.btnGames = new System.Windows.Forms.Button();
            this.highlightPanel = new System.Windows.Forms.Panel();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.labelBLS = new System.Windows.Forms.Label();
            this.menuPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuPanel
            // 
            this.menuPanel.BackColor = System.Drawing.Color.Navy;
            this.menuPanel.Controls.Add(this.BtnSetting);
            this.menuPanel.Controls.Add(this.btnTeams);
            this.menuPanel.Controls.Add(this.btnStandings);
            this.menuPanel.Controls.Add(this.btnPlayers);
            this.menuPanel.Controls.Add(this.btnGames);
            this.menuPanel.Controls.Add(this.highlightPanel);
            this.menuPanel.Controls.Add(this.btnMainMenu);
            this.menuPanel.Controls.Add(this.labelBLS);
            this.menuPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuPanel.Location = new System.Drawing.Point(0, 0);
            this.menuPanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.menuPanel.Name = "menuPanel";
            this.menuPanel.Size = new System.Drawing.Size(162, 502);
            this.menuPanel.TabIndex = 0;
            this.menuPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.menuPanel_MouseDown);
            this.menuPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.menuPanel_MouseMove);
            this.menuPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.menuPanel_MouseUp);
            // 
            // BtnSetting
            // 
            this.BtnSetting.FlatAppearance.BorderSize = 0;
            this.BtnSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSetting.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSetting.ForeColor = System.Drawing.Color.White;
            this.BtnSetting.Location = new System.Drawing.Point(5, 476);
            this.BtnSetting.Name = "BtnSetting";
            this.BtnSetting.Size = new System.Drawing.Size(89, 23);
            this.BtnSetting.TabIndex = 7;
            this.BtnSetting.Text = "Settings";
            this.BtnSetting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSetting.UseVisualStyleBackColor = true;
            this.BtnSetting.Click += new System.EventHandler(this.BtnSetting_Click);
            // 
            // btnTeams
            // 
            this.btnTeams.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTeams.FlatAppearance.BorderSize = 0;
            this.btnTeams.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTeams.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeams.ForeColor = System.Drawing.Color.White;
            this.btnTeams.Location = new System.Drawing.Point(5, 264);
            this.btnTeams.Name = "btnTeams";
            this.btnTeams.Size = new System.Drawing.Size(157, 45);
            this.btnTeams.TabIndex = 6;
            this.btnTeams.Text = "Teams";
            this.btnTeams.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTeams.UseVisualStyleBackColor = true;
            this.btnTeams.Click += new System.EventHandler(this.btnTeams_Click);
            this.btnTeams.MouseEnter += new System.EventHandler(this.btnTeams_MouseEnter);
            this.btnTeams.MouseLeave += new System.EventHandler(this.btnTeams_MouseLeave);
            // 
            // btnStandings
            // 
            this.btnStandings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStandings.FlatAppearance.BorderSize = 0;
            this.btnStandings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStandings.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStandings.ForeColor = System.Drawing.Color.White;
            this.btnStandings.Location = new System.Drawing.Point(5, 174);
            this.btnStandings.Name = "btnStandings";
            this.btnStandings.Size = new System.Drawing.Size(157, 45);
            this.btnStandings.TabIndex = 5;
            this.btnStandings.Text = "Standings";
            this.btnStandings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStandings.UseVisualStyleBackColor = true;
            this.btnStandings.Click += new System.EventHandler(this.btnStandings_Click);
            this.btnStandings.MouseEnter += new System.EventHandler(this.btnStandings_MouseEnter);
            this.btnStandings.MouseLeave += new System.EventHandler(this.btnStandings_MouseLeave);
            // 
            // btnPlayers
            // 
            this.btnPlayers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPlayers.FlatAppearance.BorderSize = 0;
            this.btnPlayers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlayers.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlayers.ForeColor = System.Drawing.Color.White;
            this.btnPlayers.Location = new System.Drawing.Point(5, 219);
            this.btnPlayers.Name = "btnPlayers";
            this.btnPlayers.Size = new System.Drawing.Size(157, 45);
            this.btnPlayers.TabIndex = 4;
            this.btnPlayers.Text = "Players";
            this.btnPlayers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPlayers.UseVisualStyleBackColor = true;
            this.btnPlayers.Click += new System.EventHandler(this.btnPlayers_Click);
            this.btnPlayers.MouseEnter += new System.EventHandler(this.btnPlayers_MouseEnter);
            this.btnPlayers.MouseLeave += new System.EventHandler(this.btnPlayers_MouseLeave);
            // 
            // btnGames
            // 
            this.btnGames.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGames.FlatAppearance.BorderSize = 0;
            this.btnGames.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGames.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGames.ForeColor = System.Drawing.Color.White;
            this.btnGames.Location = new System.Drawing.Point(5, 129);
            this.btnGames.Name = "btnGames";
            this.btnGames.Size = new System.Drawing.Size(157, 45);
            this.btnGames.TabIndex = 3;
            this.btnGames.Text = "Games";
            this.btnGames.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGames.UseVisualStyleBackColor = true;
            this.btnGames.Click += new System.EventHandler(this.btnGames_Click);
            this.btnGames.MouseEnter += new System.EventHandler(this.btnGames_MouseEnter);
            this.btnGames.MouseLeave += new System.EventHandler(this.btnGames_MouseLeave);
            // 
            // highlightPanel
            // 
            this.highlightPanel.BackColor = System.Drawing.Color.GhostWhite;
            this.highlightPanel.Location = new System.Drawing.Point(0, 84);
            this.highlightPanel.Name = "highlightPanel";
            this.highlightPanel.Size = new System.Drawing.Size(5, 45);
            this.highlightPanel.TabIndex = 2;
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMainMenu.FlatAppearance.BorderSize = 0;
            this.btnMainMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMainMenu.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.ForeColor = System.Drawing.Color.White;
            this.btnMainMenu.Location = new System.Drawing.Point(5, 84);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(157, 45);
            this.btnMainMenu.TabIndex = 1;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            this.btnMainMenu.MouseEnter += new System.EventHandler(this.btnMainMenu_MouseEnter);
            this.btnMainMenu.MouseLeave += new System.EventHandler(this.btnMainMenu_MouseLeave);
            // 
            // labelBLS
            // 
            this.labelBLS.AutoSize = true;
            this.labelBLS.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBLS.ForeColor = System.Drawing.Color.White;
            this.labelBLS.Location = new System.Drawing.Point(65, 18);
            this.labelBLS.Name = "labelBLS";
            this.labelBLS.Size = new System.Drawing.Size(64, 45);
            this.labelBLS.TabIndex = 0;
            this.labelBLS.Text = "Basketball\r\nLeague\r\nSystem";
            // 
            // GuestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(783, 502);
            this.Controls.Add(this.menuPanel);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "GuestForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guest Form";
            this.Load += new System.EventHandler(this.GuestForm_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GuestForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GuestForm_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.GuestForm_MouseUp);
            this.menuPanel.ResumeLayout(false);
            this.menuPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menuPanel;
        private System.Windows.Forms.Panel highlightPanel;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label labelBLS;
        private System.Windows.Forms.Button btnTeams;
        private System.Windows.Forms.Button btnStandings;
        private System.Windows.Forms.Button btnPlayers;
        private System.Windows.Forms.Button btnGames;
        private System.Windows.Forms.Button BtnSetting;
    }
}