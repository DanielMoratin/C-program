﻿namespace BLS___AppDev22
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelBLS = new System.Windows.Forms.Label();
            this.label2019 = new System.Windows.Forms.Label();
            this.label1stLine = new System.Windows.Forms.Label();
            this.label2ndLine = new System.Windows.Forms.Label();
            this.rightPanel = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.labelLogInAs = new System.Windows.Forms.Label();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.btnGuest = new System.Windows.Forms.Button();
            this.labelOr = new System.Windows.Forms.Label();
            this.label3rdLine = new System.Windows.Forms.Label();
            this.adminLogin = new BLS___AppDev22.AdminLogin();
            this.rightPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelBLS
            // 
            this.labelBLS.AutoSize = true;
            this.labelBLS.Font = new System.Drawing.Font("Century Gothic", 90F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBLS.Location = new System.Drawing.Point(3, 9);
            this.labelBLS.Name = "labelBLS";
            this.labelBLS.Size = new System.Drawing.Size(245, 141);
            this.labelBLS.TabIndex = 0;
            this.labelBLS.Text = "BLS";
            // 
            // label2019
            // 
            this.label2019.AutoSize = true;
            this.label2019.BackColor = System.Drawing.Color.Transparent;
            this.label2019.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2019.Location = new System.Drawing.Point(206, 109);
            this.label2019.Name = "label2019";
            this.label2019.Size = new System.Drawing.Size(46, 21);
            this.label2019.TabIndex = 1;
            this.label2019.Text = "2019";
            // 
            // label1stLine
            // 
            this.label1stLine.AutoSize = true;
            this.label1stLine.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1stLine.Location = new System.Drawing.Point(26, 168);
            this.label1stLine.Name = "label1stLine";
            this.label1stLine.Size = new System.Drawing.Size(206, 24);
            this.label1stLine.TabIndex = 2;
            this.label1stLine.Text = "An application that";
            // 
            // label2ndLine
            // 
            this.label2ndLine.AutoSize = true;
            this.label2ndLine.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2ndLine.Location = new System.Drawing.Point(26, 208);
            this.label2ndLine.Name = "label2ndLine";
            this.label2ndLine.Size = new System.Drawing.Size(209, 24);
            this.label2ndLine.TabIndex = 3;
            this.label2ndLine.Text = "organize basketball";
            // 
            // rightPanel
            // 
            this.rightPanel.BackColor = System.Drawing.Color.MidnightBlue;
            this.rightPanel.Controls.Add(this.btnClose);
            this.rightPanel.Location = new System.Drawing.Point(300, 0);
            this.rightPanel.Name = "rightPanel";
            this.rightPanel.Size = new System.Drawing.Size(300, 400);
            this.rightPanel.TabIndex = 4;
            this.rightPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.RightPanel_MouseDown);
            this.rightPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.RightPanel_MouseMove);
            this.rightPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.RightPanel_MouseUp);
            // 
            // btnClose
            // 
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(273, -3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 30);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "&x";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // labelLogInAs
            // 
            this.labelLogInAs.AutoSize = true;
            this.labelLogInAs.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogInAs.Location = new System.Drawing.Point(26, 327);
            this.labelLogInAs.Name = "labelLogInAs";
            this.labelLogInAs.Size = new System.Drawing.Size(73, 20);
            this.labelLogInAs.TabIndex = 5;
            this.labelLogInAs.Text = "Log-in as";
            // 
            // btnAdmin
            // 
            this.btnAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdmin.FlatAppearance.BorderSize = 0;
            this.btnAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdmin.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmin.ForeColor = System.Drawing.Color.White;
            this.btnAdmin.Location = new System.Drawing.Point(207, 323);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Size = new System.Drawing.Size(66, 28);
            this.btnAdmin.TabIndex = 6;
            this.btnAdmin.Text = "Admin";
            this.btnAdmin.UseVisualStyleBackColor = false;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // btnGuest
            // 
            this.btnGuest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnGuest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuest.FlatAppearance.BorderSize = 0;
            this.btnGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuest.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuest.ForeColor = System.Drawing.Color.White;
            this.btnGuest.Location = new System.Drawing.Point(105, 323);
            this.btnGuest.Name = "btnGuest";
            this.btnGuest.Size = new System.Drawing.Size(66, 28);
            this.btnGuest.TabIndex = 7;
            this.btnGuest.Text = "Guest";
            this.btnGuest.UseVisualStyleBackColor = false;
            this.btnGuest.Click += new System.EventHandler(this.btnGuest_Click);
            // 
            // labelOr
            // 
            this.labelOr.AutoSize = true;
            this.labelOr.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOr.Location = new System.Drawing.Point(177, 327);
            this.labelOr.Name = "labelOr";
            this.labelOr.Size = new System.Drawing.Size(24, 20);
            this.labelOr.TabIndex = 8;
            this.labelOr.Text = "or";
            // 
            // label3rdLine
            // 
            this.label3rdLine.AutoSize = true;
            this.label3rdLine.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3rdLine.Location = new System.Drawing.Point(26, 248);
            this.label3rdLine.Name = "label3rdLine";
            this.label3rdLine.Size = new System.Drawing.Size(145, 24);
            this.label3rdLine.TabIndex = 9;
            this.label3rdLine.Text = "tournaments.";
            // 
            // adminLogin
            // 
            this.adminLogin.BackColor = System.Drawing.Color.White;
            this.adminLogin.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminLogin.Location = new System.Drawing.Point(0, 0);
            this.adminLogin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.adminLogin.Name = "adminLogin";
            this.adminLogin.Size = new System.Drawing.Size(300, 400);
            this.adminLogin.TabIndex = 10;
            this.adminLogin.Visible = false;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(600, 400);
            this.Controls.Add(this.adminLogin);
            this.Controls.Add(this.label3rdLine);
            this.Controls.Add(this.labelOr);
            this.Controls.Add(this.btnGuest);
            this.Controls.Add(this.btnAdmin);
            this.Controls.Add(this.labelLogInAs);
            this.Controls.Add(this.rightPanel);
            this.Controls.Add(this.label2ndLine);
            this.Controls.Add(this.label1stLine);
            this.Controls.Add(this.label2019);
            this.Controls.Add(this.labelBLS);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login Form";
            this.Load += new System.EventHandler(this.LoginForm_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LoginForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LoginForm_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LoginForm_MouseUp);
            this.rightPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelBLS;
        private System.Windows.Forms.Label label2019;
        private System.Windows.Forms.Label label1stLine;
        private System.Windows.Forms.Label label2ndLine;
        private System.Windows.Forms.Panel rightPanel;
        private System.Windows.Forms.Label labelLogInAs;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.Button btnGuest;
        private System.Windows.Forms.Label labelOr;
        private System.Windows.Forms.Label label3rdLine;
        private System.Windows.Forms.Button btnClose;
        private AdminLogin adminLogin;
    }
}

