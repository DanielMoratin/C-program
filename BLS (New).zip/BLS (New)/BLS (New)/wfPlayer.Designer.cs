﻿namespace BLS__New_
{
    partial class wfPlayer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pHeader = new System.Windows.Forms.Panel();
            this.lblDetial = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnAP = new System.Windows.Forms.Button();
            this.btnFA = new System.Windows.Forms.Button();
            this.btnCP = new System.Windows.Forms.Button();
            this.pAP = new System.Windows.Forms.Panel();
            this.btnSearchAP = new System.Windows.Forms.Button();
            this.tbSearchAP = new System.Windows.Forms.TextBox();
            this.cbAPsort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lvAP = new System.Windows.Forms.ListView();
            this.lvPlayerId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvHomePlace = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvTeam = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.refresh1 = new System.Windows.Forms.Label();
            this.pHeader.SuspendLayout();
            this.pAP.SuspendLayout();
            this.SuspendLayout();
            // 
            // pHeader
            // 
            this.pHeader.Controls.Add(this.lblDetial);
            this.pHeader.Controls.Add(this.lblTitle);
            this.pHeader.Controls.Add(this.btnAP);
            this.pHeader.Controls.Add(this.btnFA);
            this.pHeader.Controls.Add(this.btnCP);
            this.pHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pHeader.Location = new System.Drawing.Point(0, 0);
            this.pHeader.Name = "pHeader";
            this.pHeader.Size = new System.Drawing.Size(686, 100);
            this.pHeader.TabIndex = 4;
            // 
            // lblDetial
            // 
            this.lblDetial.AutoSize = true;
            this.lblDetial.Location = new System.Drawing.Point(37, 42);
            this.lblDetial.Name = "lblDetial";
            this.lblDetial.Size = new System.Drawing.Size(228, 13);
            this.lblDetial.TabIndex = 4;
            this.lblDetial.Text = "All Players List As Of MM/dd/yyyy  hh:mm:ss  tt";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(37, 14);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(220, 13);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "BASKETBALL LEAGUE SYSTEM PLAYERS";
            // 
            // btnAP
            // 
            this.btnAP.Location = new System.Drawing.Point(40, 74);
            this.btnAP.Name = "btnAP";
            this.btnAP.Size = new System.Drawing.Size(90, 23);
            this.btnAP.TabIndex = 0;
            this.btnAP.Text = "All Player";
            this.btnAP.UseVisualStyleBackColor = true;
            this.btnAP.Click += new System.EventHandler(this.btnAP_Click);
            // 
            // btnFA
            // 
            this.btnFA.Location = new System.Drawing.Point(383, 74);
            this.btnFA.Name = "btnFA";
            this.btnFA.Size = new System.Drawing.Size(90, 23);
            this.btnFA.TabIndex = 2;
            this.btnFA.Text = "Free Agent";
            this.btnFA.UseVisualStyleBackColor = true;
            // 
            // btnCP
            // 
            this.btnCP.Location = new System.Drawing.Point(206, 74);
            this.btnCP.Name = "btnCP";
            this.btnCP.Size = new System.Drawing.Size(90, 23);
            this.btnCP.TabIndex = 1;
            this.btnCP.Text = "Contract Player";
            this.btnCP.UseVisualStyleBackColor = true;
            // 
            // pAP
            // 
            this.pAP.AutoScroll = true;
            this.pAP.Controls.Add(this.btnSearchAP);
            this.pAP.Controls.Add(this.tbSearchAP);
            this.pAP.Controls.Add(this.cbAPsort);
            this.pAP.Controls.Add(this.label1);
            this.pAP.Controls.Add(this.lvAP);
            this.pAP.Controls.Add(this.refresh1);
            this.pAP.Location = new System.Drawing.Point(3, 103);
            this.pAP.Name = "pAP";
            this.pAP.Size = new System.Drawing.Size(680, 344);
            this.pAP.TabIndex = 5;
            // 
            // btnSearchAP
            // 
            this.btnSearchAP.Location = new System.Drawing.Point(314, 5);
            this.btnSearchAP.Name = "btnSearchAP";
            this.btnSearchAP.Size = new System.Drawing.Size(75, 24);
            this.btnSearchAP.TabIndex = 5;
            this.btnSearchAP.Text = "Find player";
            this.btnSearchAP.UseVisualStyleBackColor = true;
            this.btnSearchAP.Click += new System.EventHandler(this.btnSearchAP_Click);
            // 
            // tbSearchAP
            // 
            this.tbSearchAP.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbSearchAP.Location = new System.Drawing.Point(390, 7);
            this.tbSearchAP.Name = "tbSearchAP";
            this.tbSearchAP.Size = new System.Drawing.Size(100, 20);
            this.tbSearchAP.TabIndex = 4;
            this.tbSearchAP.Text = "Search Player";
            this.tbSearchAP.TextChanged += new System.EventHandler(this.tbSearchAP_TextChanged);
            this.tbSearchAP.Enter += new System.EventHandler(this.tbSearchAP_Enter);
            this.tbSearchAP.Leave += new System.EventHandler(this.tbSearchAP_Leave);
            // 
            // cbAPsort
            // 
            this.cbAPsort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAPsort.FormattingEnabled = true;
            this.cbAPsort.Items.AddRange(new object[] {
            "Name",
            "Team"});
            this.cbAPsort.Location = new System.Drawing.Point(68, 6);
            this.cbAPsort.Name = "cbAPsort";
            this.cbAPsort.Size = new System.Drawing.Size(121, 21);
            this.cbAPsort.TabIndex = 3;
            this.cbAPsort.SelectedIndexChanged += new System.EventHandler(this.cbAPsort_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sort by : ";
            // 
            // lvAP
            // 
            this.lvAP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvAP.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvPlayerId,
            this.lvName,
            this.lvHomePlace,
            this.lvTeam});
            this.lvAP.FullRowSelect = true;
            this.lvAP.GridLines = true;
            this.lvAP.HideSelection = false;
            this.lvAP.Location = new System.Drawing.Point(14, 31);
            this.lvAP.MultiSelect = false;
            this.lvAP.Name = "lvAP";
            this.lvAP.Size = new System.Drawing.Size(653, 298);
            this.lvAP.TabIndex = 1;
            this.lvAP.UseCompatibleStateImageBehavior = false;
            this.lvAP.View = System.Windows.Forms.View.Details;
            this.lvAP.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lvAP_MouseDoubleClick);
            // 
            // lvPlayerId
            // 
            this.lvPlayerId.Text = "ID";
            this.lvPlayerId.Width = 115;
            // 
            // lvName
            // 
            this.lvName.Text = "Name";
            this.lvName.Width = 187;
            // 
            // lvHomePlace
            // 
            this.lvHomePlace.Text = "Home Place";
            this.lvHomePlace.Width = 202;
            // 
            // lvTeam
            // 
            this.lvTeam.Text = "Team";
            this.lvTeam.Width = 138;
            // 
            // refresh1
            // 
            this.refresh1.AutoSize = true;
            this.refresh1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refresh1.ForeColor = System.Drawing.Color.Blue;
            this.refresh1.Location = new System.Drawing.Point(623, 9);
            this.refresh1.Name = "refresh1";
            this.refresh1.Size = new System.Drawing.Size(44, 13);
            this.refresh1.TabIndex = 0;
            this.refresh1.Text = "Refresh";
            this.refresh1.Click += new System.EventHandler(this.refresh1_Click);
            // 
            // wfPlayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.pAP);
            this.Controls.Add(this.pHeader);
            this.Name = "wfPlayer";
            this.Size = new System.Drawing.Size(686, 450);
            this.Load += new System.EventHandler(this.wfPlayer_Load);
            this.pHeader.ResumeLayout(false);
            this.pHeader.PerformLayout();
            this.pAP.ResumeLayout(false);
            this.pAP.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pHeader;
        private System.Windows.Forms.Label lblDetial;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnAP;
        private System.Windows.Forms.Button btnFA;
        private System.Windows.Forms.Button btnCP;
        private System.Windows.Forms.Panel pAP;
        private System.Windows.Forms.Label refresh1;
        private System.Windows.Forms.ListView lvAP;
        private System.Windows.Forms.ColumnHeader lvPlayerId;
        private System.Windows.Forms.ColumnHeader lvName;
        private System.Windows.Forms.ColumnHeader lvHomePlace;
        private System.Windows.Forms.ColumnHeader lvTeam;
        private System.Windows.Forms.TextBox tbSearchAP;
        private System.Windows.Forms.ComboBox cbAPsort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearchAP;
    }
}
