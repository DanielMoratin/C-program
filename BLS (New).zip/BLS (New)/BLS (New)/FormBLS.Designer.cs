﻿namespace BLS__New_
{
    partial class FormBLS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMM = new System.Windows.Forms.Button();
            this.btnP = new System.Windows.Forms.Button();
            this.btnT = new System.Windows.Forms.Button();
            this.btnS = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnG = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.wfFile1 = new BLS__New_.wfFile();
            this.wfPlayer1 = new BLS__New_.wfPlayer();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMM
            // 
            this.btnMM.Location = new System.Drawing.Point(14, 13);
            this.btnMM.Name = "btnMM";
            this.btnMM.Size = new System.Drawing.Size(75, 23);
            this.btnMM.TabIndex = 0;
            this.btnMM.Text = "Main Menu";
            this.btnMM.UseVisualStyleBackColor = true;
            // 
            // btnP
            // 
            this.btnP.Location = new System.Drawing.Point(14, 42);
            this.btnP.Name = "btnP";
            this.btnP.Size = new System.Drawing.Size(75, 23);
            this.btnP.TabIndex = 1;
            this.btnP.Text = "Players";
            this.btnP.UseVisualStyleBackColor = true;
            this.btnP.Click += new System.EventHandler(this.btnP_Click);
            // 
            // btnT
            // 
            this.btnT.Location = new System.Drawing.Point(14, 71);
            this.btnT.Name = "btnT";
            this.btnT.Size = new System.Drawing.Size(75, 23);
            this.btnT.TabIndex = 2;
            this.btnT.Text = "Teams";
            this.btnT.UseVisualStyleBackColor = true;
            // 
            // btnS
            // 
            this.btnS.Location = new System.Drawing.Point(14, 100);
            this.btnS.Name = "btnS";
            this.btnS.Size = new System.Drawing.Size(75, 23);
            this.btnS.TabIndex = 3;
            this.btnS.Text = "Standings";
            this.btnS.UseVisualStyleBackColor = true;
            // 
            // btnF
            // 
            this.btnF.Location = new System.Drawing.Point(14, 129);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(75, 23);
            this.btnF.TabIndex = 4;
            this.btnF.Text = "File";
            this.btnF.UseVisualStyleBackColor = true;
            this.btnF.Click += new System.EventHandler(this.btnF_Click);
            // 
            // btnG
            // 
            this.btnG.Location = new System.Drawing.Point(14, 158);
            this.btnG.Name = "btnG";
            this.btnG.Size = new System.Drawing.Size(75, 23);
            this.btnG.TabIndex = 5;
            this.btnG.Text = "Post Game";
            this.btnG.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnMM);
            this.panel1.Controls.Add(this.btnG);
            this.panel1.Controls.Add(this.btnP);
            this.panel1.Controls.Add(this.btnF);
            this.panel1.Controls.Add(this.btnT);
            this.panel1.Controls.Add(this.btnS);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(114, 450);
            this.panel1.TabIndex = 6;
            // 
            // wfFile1
            // 
            this.wfFile1.AutoScroll = true;
            this.wfFile1.Location = new System.Drawing.Point(114, 0);
            this.wfFile1.Name = "wfFile1";
            this.wfFile1.Size = new System.Drawing.Size(686, 450);
            this.wfFile1.TabIndex = 7;
            // 
            // wfPlayer1
            // 
            this.wfPlayer1.AutoScroll = true;
            this.wfPlayer1.Location = new System.Drawing.Point(114, 0);
            this.wfPlayer1.Name = "wfPlayer1";
            this.wfPlayer1.Size = new System.Drawing.Size(686, 450);
            this.wfPlayer1.TabIndex = 8;
            // 
            // FormBLS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.wfPlayer1);
            this.Controls.Add(this.wfFile1);
            this.Controls.Add(this.panel1);
            this.Name = "FormBLS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BLS";
            this.Load += new System.EventHandler(this.FormBLS_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMM;
        private System.Windows.Forms.Button btnP;
        private System.Windows.Forms.Button btnT;
        private System.Windows.Forms.Button btnS;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnG;
        private System.Windows.Forms.Panel panel1;
        private wfFile wfFile1;
        private wfPlayer wfPlayer1;
    }
}

