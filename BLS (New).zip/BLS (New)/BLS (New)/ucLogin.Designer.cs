﻿namespace BLS__New_
{
    partial class ucLogin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginPanel = new System.Windows.Forms.Panel();
            this.createAccount = new System.Windows.Forms.Label();
            this.guestLogin = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.loginPassword = new System.Windows.Forms.TextBox();
            this.loginID = new System.Windows.Forms.TextBox();
            this.loginSP = new System.Windows.Forms.CheckBox();
            this.loginPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // loginPanel
            // 
            this.loginPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.loginPanel.Controls.Add(this.loginSP);
            this.loginPanel.Controls.Add(this.createAccount);
            this.loginPanel.Controls.Add(this.guestLogin);
            this.loginPanel.Controls.Add(this.btnLogin);
            this.loginPanel.Controls.Add(this.loginPassword);
            this.loginPanel.Controls.Add(this.loginID);
            this.loginPanel.Location = new System.Drawing.Point(0, 0);
            this.loginPanel.Name = "loginPanel";
            this.loginPanel.Size = new System.Drawing.Size(800, 70);
            this.loginPanel.TabIndex = 0;
            // 
            // createAccount
            // 
            this.createAccount.AutoSize = true;
            this.createAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createAccount.Location = new System.Drawing.Point(701, 36);
            this.createAccount.Name = "createAccount";
            this.createAccount.Size = new System.Drawing.Size(80, 13);
            this.createAccount.TabIndex = 4;
            this.createAccount.Text = "Create account";
            // 
            // guestLogin
            // 
            this.guestLogin.AutoSize = true;
            this.guestLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guestLogin.Location = new System.Drawing.Point(389, 36);
            this.guestLogin.Name = "guestLogin";
            this.guestLogin.Size = new System.Drawing.Size(78, 13);
            this.guestLogin.TabIndex = 3;
            this.guestLogin.Text = "Login as Guest";
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(704, 10);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(84, 23);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Log In";
            this.btnLogin.UseVisualStyleBackColor = true;
            // 
            // loginPassword
            // 
            this.loginPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginPassword.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.loginPassword.Location = new System.Drawing.Point(548, 12);
            this.loginPassword.Name = "loginPassword";
            this.loginPassword.Size = new System.Drawing.Size(150, 20);
            this.loginPassword.TabIndex = 1;
            this.loginPassword.Text = "Password";
            // 
            // loginID
            // 
            this.loginID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginID.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.loginID.Location = new System.Drawing.Point(392, 12);
            this.loginID.Name = "loginID";
            this.loginID.Size = new System.Drawing.Size(150, 20);
            this.loginID.TabIndex = 0;
            this.loginID.Text = "Username or Email";
            // 
            // loginSP
            // 
            this.loginSP.AutoSize = true;
            this.loginSP.Location = new System.Drawing.Point(548, 35);
            this.loginSP.Name = "loginSP";
            this.loginSP.Size = new System.Drawing.Size(101, 17);
            this.loginSP.TabIndex = 5;
            this.loginSP.Text = "Show password";
            this.loginSP.UseVisualStyleBackColor = true;
            // 
            // ucLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.loginPanel);
            this.Name = "ucLogin";
            this.Size = new System.Drawing.Size(800, 450);
            this.loginPanel.ResumeLayout(false);
            this.loginPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel loginPanel;
        private System.Windows.Forms.Label createAccount;
        private System.Windows.Forms.Label guestLogin;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox loginPassword;
        private System.Windows.Forms.TextBox loginID;
        private System.Windows.Forms.CheckBox loginSP;
    }
}
