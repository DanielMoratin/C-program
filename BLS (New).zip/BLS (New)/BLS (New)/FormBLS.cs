﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLS__New_
{
    public partial class FormBLS : Form
    {
        public FormBLS()
        {
            InitializeComponent();
        }

        private void FormBLS_Load(object sender, EventArgs e)
        {
            wfFile1.getFB(this);
            wfPlayer1.Visible = false;
            wfFile1.Visible = false;
        }
        public void refreshAll(object sender, EventArgs e)
        {
            wfPlayer1.refresh1_Click(sender, e);
        }
        private void btnP_Click(object sender, EventArgs e)
        {
            wfPlayer1.Visible = true;
            wfPlayer1.BringToFront();
            wfFile1.Visible = false;
            wfFile1.SendToBack();
        }

        private void btnF_Click(object sender, EventArgs e)
        {
            wfFile1.Visible = true; 
            wfFile1.BringToFront();
            wfPlayer1.Visible = false;
            wfPlayer1.SendToBack();
        }
    }
}
